<div id="example1"></div>


<script src="../Controladores/pdf/pdfobject.js"></script>
<script>PDFObject.embed("./prueba.pdf", "#example1");</script>

<style>
.pdfobject-container { height: 500px;}
.pdfobject { border: 1px solid #666; }
</style>