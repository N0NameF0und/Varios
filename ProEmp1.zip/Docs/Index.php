<?php

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Página Principal</title>

    <!-- logo -->
    <link href="./imagenes/favicon.ico" type="image/x-icon" rel="shortcut icon">
    <!-- bootstrap temas -->
    <link href="./css/1bootstrap.min.css" rel="stylesheet">
    <!-- fuente -->
    <link rel="stylesheet" href="./css/font-awesome.min.css">
    <!-- animacion boton -->
    <link rel="stylesheet" href="./css/animate.css">
    <!--<link rel="stylesheet" href="../../../cdn.jsdelivr.net/animatecss/3.1.0/animate.css">-->
    <!-- scroll -->
    <link href="./css/scrolling-nav.css" rel="stylesheet">
    <!-- fuentes -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,700italic,300,400,700' rel='stylesheet'
        type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:light' rel='stylesheet' type='text/css'>
    <script src="jquery-3.3.1.min.js"></script>

</head>

<body>
    <div class="container">
        <br>
        <nav class="navbar navbar-expand-lg navbar-light bg-light border border-danger rounded">
            &nbsp;&nbsp;&nbsp;
            <a class="navbar-brand" href="#">
                <img src="" alt="Imagen" height="45px" width="75px">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Inicio
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./php/logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </nav>
        <br>
        <br>
        <div class="card-deck">
            <div class="card border border-danger rounded">
                <img class="card-img-top" src="" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Subir archivos</h5>
                    <p class="card-text">Seleccione los archivos .</p>
                    <p class="card-text">
                        <center>
                                <button type="button" name="subir" class="btn btn-outline-danger">Ingresar</button>
                        </center>
                    </p>
                </div>
            </div>
            <div class="card border border-danger rounded">
                <img class="card-img-top" src="" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Administracion de Procesos</h5>
                    <p class="card-text">Valoracion.</p>
                    <p class="card-text">
                        <center>
                                <button type="button" name="administrar" class="btn btn-outline-danger" href="#">Ingresar</button>
                        </center>
                    </p>
                </div>
            </div>
            <div class="card border border-danger rounded">
                <img class="card-img-top" src="" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Distribucion de Archivos</h5>
                    <p class="card-text">Separacion de contendios.</p>
                    <p class="card-text">
                        <center>
                                <button type="button" name="distribuir" class="btn btn-outline-danger">Ingresar</button>
                        </center>
                    </p>
                </div>
            </div>
            <div class="card border border-danger rounded">
                <img class="card-img-top" src="" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title center">Gestion de Documentacion</h5>
                    <p class="card-text">Control de Ingresos y salidas.</p>
                    <p class="card-text">
                        <center>
                                <button type="button" name="gestionar" class="btn btn-outline-danger">Ingresar</button>
                        </center>
                    </p>
                </div>
            </div>
        </div>

        <script>
    $(document).ready(function () {
    /* $('#Python').click(function () {
        $("#contenido").load("c_python.html");
    }); */

    $('button').click(function () {
        var nombre=$(this).attr("name");
        var link= "./complementarias/"+nombre+".ini.php" ;
        $("#contenido").load(link);
    });
});
        </script>
        <div class="card border border-danger rounded" style="widht:100%;margin-top:20px;">
                
                <div class="card-body" id="contenido">
                   
                </div>
            </div>


    </div>


</body>

</html>